DESK RACER v4 PACKAGE
1. DeskRacer_v4_Prompt.md -> paste into your AI Studio project as one message.
2. assets/  -> asset pack v4. Replace app/src/main/assets in AI Studio with this folder if it lets you upload
              (my GitHub build already uses it, so the APK is correct either way).
   v4 fixes: DRM2 textures were upside-down (UV origin) -> fixed in the files themselves.
   New: 9 more real models (arched lamp, table lamp, flight helmet, boombox, sneaker, fox, fish, velvet sofa, damask chair),
        normal maps for all surfaces, 11 decals (coffee rings, sticky notes, paint splats, skid marks, boost chevrons),
        HUD item icons + kart thumbnails rendered from the real models, track preview cards, garage turntable,
        track JSONs with decals + previewCard + normal maps.
3. refs/    -> 16 reference renders (chase + top view per track) made from this exact pack = the target look.
              Upload to a refs/ folder in AI Studio if possible; the prompt points to it.
4. previews/ -> contact sheets.
CC-BY credits: assets/CREDITS.txt (must stay visible in-app).
