DESK RACER v3 PACKAGE
1. DeskRacer_v3_Prompt.md  -> paste into your AI Studio project as one message.
2. assets/                 -> realistic asset pack (also already in the GitHub repo; the build merges it automatically).
                              If AI Studio lets you upload files, add assets/ to app/src/main/assets so its preview shows them.
3. brand/                  -> app icon (SVG sources, Android mipmaps, adaptive layers), Play Store icon 512, feature graphic, wordmark, Poppins (in brand/android_res/font).
4. previews/               -> contact sheets of the props, items, surfaces, backdrops and track dressing.
Credits for CC-BY models are in assets/CREDITS.txt and must stay visible in the app (Settings -> About).
