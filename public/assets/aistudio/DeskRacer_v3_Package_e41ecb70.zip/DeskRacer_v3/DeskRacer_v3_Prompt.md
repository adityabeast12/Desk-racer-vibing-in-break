DESK RACER LAN — v3 "REAL WORLD" UPGRADE
Master prompt for Google AI Studio. Paste all of it as one message. Builds on the existing v2 project.

You are the lead engineer, technical artist and UX designer for Desk Racer LAN (Kotlin, Jetpack Compose, OpenGL ES, package `com.example`). v2 works: races finish, there are 8 tracks, items, bots and hotspot multiplayer. v3 has three goals:

1. Make the WORLD LOOK REAL. Replace every primitive placeholder ("round balls", boxes) with the textured 3D models, surface textures and room backdrops in the asset pack.
2. Make the UI CLEAN AND SAFE. Poppins everywhere, nothing ever overlaps, and controls feel great.
3. Prepare the game to EARN without hurting players (Part J).

Follow every section. Where exact values, file names or formats are given, use them exactly.

====================================================================
PART A — HARD RULES (unchanged + new)
====================================================================
A1. Do NOT modify `signingConfigs`, `signingConfig` lines, `applicationId`, `namespace` or the plugin block. minSdk 24, targetSdk 36, `sensorLandscape`, immersive.
A2. Gameplay is 100% offline. LAN sockets only. Optional online features (Part J) must never be required to play.
A3. ASSETS ARE PROVIDED (Part B). The build pipeline merges them into `app/src/main/assets/` and also overrides `app/src/main/res/mipmap-*` (new app icon) and `app/src/main/res/font/poppins_*.ttf`. Load assets through one `AssetRepository` and fall back to procedural geometry when a file is missing (the AI Studio preview may not have them). Never crash on a missing asset. Do not delete, rename or regenerate files in `assets/`, `res/mipmap-*` or `res/font/poppins_*`.
A4. If `res/font/poppins_*.ttf` are not in this workspace, ADD Poppins from Google Fonts yourself with the same file names (poppins_regular, poppins_medium, poppins_semibold, poppins_bold, poppins_extrabold, poppins_black, poppins_italic), exactly as orbitron.ttf was added before. The pipeline overwrites them with the official files.
A5. Compile after every phase (Part M). No TODO stubs, no `!!` on runtime-nullable values, zero allocations per frame, no I/O on UI or GL threads.

====================================================================
PART B — THE ASSET PACK (what exists and how to use it)
====================================================================
Scale convention: 1 game unit = 1 cm. Models are authored in METRES, so render them with scale 100 (the track JSON already gives `scale`). Karts are ~2.2 u long, so the world feels like Micro Machines on a real desk.

B1. `asset_manifest.json` lists everything below. Read it at startup and keep a typed index.

B2. MODEL FORMATS (all little-endian):
 DRM1 (existing loader `DrmModelLoader`, keep it): karts `models/kart_*.drm`, `models/coin.drm`, `models/flag.drm`, `models/block_coin.drm`, `models/cloud.drm`. Vertex = pos3, normal3, rgb3, tint1 (10 floats).
 DRM2 (NEW, textured). Add `Drm2Loader` alongside DRM1:
   4 bytes magic "DRM2"; int32 partCount; float32[6] AABB (minX,minY,minZ,maxX,maxY,maxZ) in metres
   repeat partCount times:
     int32 nameLen + UTF-8 name
     int32 texLen + UTF-8 texture path relative to assets/ (empty = untextured)
     float32[4] baseColorFactor RGBA; float32 metallic; float32 roughness
     uint8 alphaMode (0 opaque, 1 mask (cutoff 0.5), 2 blend); uint8 doubleSided; uint8[2] padding
     float32[3] pivot (always 0 in this pack)
     int32 vertexCount; float32[vertexCount × 12] = px,py,pz, nx,ny,nz, u,v, r,g,b, tint
     int32 indexCount; uint16[indexCount] triangle list (CCW front faces)
     zero padding to the next 4-byte boundary
   Models sit on y=0, centred on X/Z, +Y up. UV v=0 is the TOP row of the image (do not flip when uploading with GLUtils.texImage2D from a Bitmap).
 TEXTURES: JPG (opaque) or PNG (alpha), max 1024 px. Load with BitmapFactory (inPreferredConfig ARGB_8888, inScaled=false), upload with mipmaps (glGenerateMipmap) and trilinear filtering, and turn on anisotropic filtering if the extension exists. Cache textures by path; one GL texture per file.

B3. PROPS (`models/props/*.drm`, realistic, textured, 0.7k–18k triangles):
 traffic_cone, water_bottle, avocado, mandarin_orange, teacup, desk_lamp (barn lamp), vase_flowers, potted_plant, chair, sofa, scifi_helmet, toy_car, lantern, olive_dish, stained_glass_lamp, and chess pieces chess_{king,queen,bishop,knight,rook,pawn}_{w,b}. Real sizes are in the manifest (e.g. teacup 7 cm tall → 7 u, desk_lamp 45 u, chess king 15 u).
B4. ITEMS (`models/items/*.drm`, original, textured): battery, thumbtack, eraser, marble, marble_homing, paper_plane, magnet, star_sticker. REPLACE every sphere and box currently used for items, projectiles, the held-item display and the HUD item icons (render the item model into a small offscreen texture for the HUD slot, or draw it with a mini GL view). Item scale: ×100 (they are authored at game size). Spin pickups slowly; marbles roll (rotation = distance / radius).
B5. SURFACES (`textures/surfaces/`): wood_walnut (+ wood_walnut_n normal map), wood_oak_light, marble_white, tiles_bath, paper_ruled, paper_paint, cardboard_kraft, desk_mat_dark, rug_playroom, road_asphalt, cutting_board, chessboard, ruler_strip.png, kerb_red_white.png, checker_finish.png. All tile seamlessly; use GL_REPEAT.
B6. BACKDROPS (`textures/backdrops/*.jpg`, 2048×1024 equirectangular, CC0 HDRIs tone-mapped): room_apartment, room_lobby, room_studio, room_workshop, city_day, window_dusk_hills. Render them on a large inside-out sphere (radius 900 u, centred on the camera, depth write off, drawn first). They are pre-blurred to read like the shallow depth of field of a macro photo of a real desk. Keep that look and add a subtle vignette.
B7. TRACKS (`tracks/<slug>.json`): THE SINGLE SOURCE OF TRUTH for the 8 layouts and their dressing. Slugs: study_desk, gamer_desk, kitchen_counter, art_desk, bookshelf_spiral, bathtub_rim, toy_box, midnight_office.
 Fields: name, slug, roadWidth, lengthApprox, controlPoints [[x,y,z]…] (closed Catmull-Rom, 18 subdivisions per segment, travel order), unitsPerMetre (100), surfaceTexture + surfaceTextureTileUnits, roadTexture + roadTextureTileUnits, kerbTexture, finishTexture, backdropEquirect, lightingPreset, music, props [{model, name, role ("pylon" | "landmark"), x, y, z, yawRad, scale, radius, solid}].
 - Load Tracks from these JSON files (keep the Kotlin definitions only as a fallback). REMOVE "WORKSHOP BENCH". The 8th track is MIDNIGHT OFFICE from the JSON. Its layout was validated; Workshop Bench has a corner tighter than the road width.
 - Every prop in the JSON is already validated to sit off the road, clear of every road section including bridges, and not overlapping other props. Place them exactly. If `solid`, collide as a vertical cylinder of `radius` (pylons too: they are the corner markers on the inside of each bend).
 - Keep the hazards, boost pads, ramps, item rows and coins from v2, but run TrackValidator against the JSON props as well.
B8. KARTS: DRM1 karts stay. ADD the realistic `toy_car` (DRM2) as a 6th body, "CLASSIC TOY": scale it so its length is 2.2 u; it has no tint mask, so offer 3 fixed liveries via a hue-shift uniform. Stats 4/2/3/3.
B9. AUDIO/MUSIC: unchanged files from v2 (`audio/sfx`, `audio/music`).
B10. CREDITS: show `CREDITS.txt` in Settings → About. It is legally required for the CC-BY models.

====================================================================
PART C — RENDERING THAT LOOKS REAL
====================================================================
C1. ONE lit material shader for DRM2 (and DRM1 with texture = white):
   albedo = texture(baseColorTex, uv) × baseColorFactor × vertexColor, then the tint mix for karts;
   lighting = hemisphere ambient (sky/ground colours per preset) + directional key light (Lambert + GGX-lite specular using roughness, metallic tints the specular by albedo) + up to 8 point/spot lights (lamps, headlights, lava lamp);
   + an environment term: sample the backdrop texture at the reflected vector with a lod/blur proportional to roughness (cheap fake IBL; use textureLod on the mip chain);
   + fresnel rim 0.04→1;
   alpha: MASK discards < 0.5; BLEND draws in the sorted transparent pass with depth write off (glass of the teacup, vase, lamp shades);
   output gamma 2.2, ACES-fitted tone-map, exposure per preset.
C2. SHADOWS: a 2048 (High) / 1024 (Medium) shadow map from the key light, fitted to a 160 u box around the player kart and updated every frame, with PCF 3×3 and normal-offset bias to avoid acne. Low quality uses blob shadows (soft dark ellipses under karts and props).
C3. CONTACT REALISM: a 0.6 u soft ambient-occlusion ring under every prop (decal quad with a radial gradient), and kart tyre-contact darkening.
C4. ROAD: build the mesh from the spline. Top UVs u = lateral 0..1 and v = distance / roadTextureTileUnits. Add red/white kerbs (kerb_red_white.png) on bends, the checker_finish.png strip at the line, white edge lines, and on elevated sections side walls plus underside and support pillars textured with wood_walnut. The DESK SURFACE is a big plane (track extent + 120 u margin) textured with surfaceTexture tiled every surfaceTextureTileUnits, with a normal map where provided, plus the desk edge, its thickness and the floor far below.
C5. LIGHTING PRESETS (keep v2 names, now tuned for realism): DUSK_LAMP (warm 3200 K key from the desk_lamp position + cool fill), NIGHT_RGB (dark, emissive strips, monitor glow), MORNING_SUN (6000 K low sun, long shadows), SUNNY_STUDIO, LIBRARY_WARM, BATHROOM_BRIGHT (soft high-key), PLAYROOM_SOFT, MIDNIGHT_CITY (blue moonlight + lamp spots + kart headlights). Each preset sets sky/ground ambient, key direction/colour/intensity, exposure, fog colour/density and backdrop tint.
C6. POST (High only): FXAA, bloom-lite on emissive, a subtle tilt-shift DOF (blur the top and bottom 18% of the screen; it strengthens the "miniature on a desk" feel), and light film grain at 2%. Each is toggleable in Settings.
C7. PERFORMANCE BUDGET: ≤ 250k triangles drawn on High, 150k Medium, 80k Low. Instance repeated props (chess pawns, cones) with glDrawElementsInstanced. Frustum-cull by bounding sphere and distance-cull decor beyond 400 u (Low: 250 u). Generate 2 LODs at load for props above 6k triangles by vertex clustering. Texture memory ≤ 96 MB.
C8. NO PLACEHOLDERS: grep the codebase and remove every remaining primitive used to represent a real object (sphere item boxes, cube props, cylinder bottles). Use the DRM2 models. Procedural geometry is allowed only for the road, walls, kerbs, desk planes, particles, and the v2 props that have no model (books, pencils, ruler, keyboard, laptop), which must stay multi-part and bevelled as specified in v2.

====================================================================
PART D — TYPOGRAPHY: POPPINS EVERYWHERE
====================================================================
D1. Replace Orbitron and Space Grotesk with ONE family:
   `val Poppins = FontFamily(Font(R.font.poppins_regular, W400), Font(R.font.poppins_medium, W500), Font(R.font.poppins_semibold, W600), Font(R.font.poppins_bold, W700), Font(R.font.poppins_extrabold, W800), Font(R.font.poppins_black, W900), Font(R.font.poppins_italic, W400, Italic))`.
   Delete orbitron.ttf and space_grotesk.ttf, and every reference to them.
D2. Type scale (sp), applied through MaterialTheme.typography and a small `DRType` object:
   Display 40/44 Black · Title 28/32 ExtraBold · Headline 22/28 Bold · Subtitle 17/24 SemiBold · Body 15/22 Regular · Label 13/18 Medium · Caption 11/14 Medium · HUD-Number 34/34 ExtraBold with fontFeatureSettings = "tnum".
   Use letterSpacing 0 except Display (−0.5) and Label caps (+0.6).
D3. All numbers that change (timer, speed, laps, position, coins) use tabular figures ("tnum"), so they never jitter or shift layout.
D4. Respect the system font scale up to 1.3× without breakage (Part E), and clamp HUD text to 1.15×.

====================================================================
PART E — UI GUARDRAILS: NOTHING EVER OVERLAPS
====================================================================
Root cause in v2: `RaceScreen` places LapTimer (TopCenter), PositionBadge (TopStart), ItemSlot (TopEnd), Minimap (CenterStart), Speedometer (BottomCenter) and ActionButtons (BottomEnd) as independent `Modifier.align` children of one Box, with fixed paddings and no shared layout. On narrow or cut-out screens they collide: the minimap sits inside the steering zone, the speedometer hits the action buttons, and the item slot competes with pause.
Fix it structurally:
E1. HUD LAYOUT ENGINE: create `ui/hud/HudLayout.kt`, a custom `Layout` composable that receives the safe drawing rect (WindowInsets.safeDrawing ∪ displayCutout) and the screen size, and places children into RESERVED ZONES computed as percentages of the safe rect:
     TOP_LEFT 0–28% w × 0–22% h → position badge, lap, coins
     TOP_CENTER 34–66% w × 0–14% h → timer and banners
     TOP_RIGHT 72–100% w × 0–22% h → item slots, then pause (pause always on the far right, item slot left of it)
     LEFT_MID 0–18% w × 26–56% h → minimap (moves here; it must not intrude into the steer zone)
     RIGHT_MID 84–100% w × 26–56% h → standings ladder
     BOTTOM_LEFT 0–40% w × 58–100% h → steering control zone (touch area; visual hint only)
     BOTTOM_CENTER 42–58% w × 78–100% h → speed + drift bar (shrinks or hides below 640 dp width)
     BOTTOM_RIGHT 60–100% w × 52–100% h → action buttons cluster
     CENTER 25–75% w × 22–70% h → countdown and toasts (non-interactive)
   Zones never intersect by construction. Each child is measured with the zone's max constraints. If content is larger, it SCALES DOWN (graphicsLayer scale, minimum 0.75) and never spills. Below 600 dp width, hide the RIGHT_MID ladder and shrink the minimap to 96 dp.
E2. TOUCH vs VISUALS: interactive zones (steer, actions, pause, item) must not overlap each other or any other interactive element. Visual-only HUD may sit above the steer zone only if it is `pointerInteropFilter`-transparent (passes touches through).
E3. MIN SIZES: every tappable element ≥ 48 dp (action buttons ≥ 72 dp), with ≥ 8 dp between tappables. The pause button gets a 56 dp hit area even if its icon is 24 dp.
E4. TEXT SAFETY: every Text has `maxLines` and `overflow = Ellipsis`, or uses an `AutoSizeText` helper (step the size down 1 sp at a time to a floor). Names are truncated to 12 chars in HUD/nameplates. No hard-coded widths for text containers; use `widthIn(min, max)`.
E5. DEBUG OVERLAY: Settings → Developer → "Show HUD zones" draws the zone rects and the actual bounds of every HUD child in red when two siblings intersect.
E6. AUTOMATED GUARANTEE (must pass): add Compose UI tests under app/src/test (Robolectric, already configured) that render RaceScreen's HUD with a fake HudState at these sizes — 640×360, 732×412, 800×360, 915×412, 1280×800 dp — and font scales 1.0 and 1.3, then assert via `onAllNodesWithTag(...).fetchSemanticsNodes()` that no two interactive nodes' `boundsInRoot` intersect and that every node lies inside the safe rect. Do the same for Main Menu, Mode Picker, Race Setup, Host Lobby, Join, Garage, Results and Settings: no clipped text (check `TextLayoutResult.hasVisualOverflow == false` via a test hook) and no overlapping buttons. Tag every HUD and menu element with `testTag`.
E7. MENUS: use a 12-column landscape grid with 24 dp outer and 16 dp gutters. Cards align to columns. Content that can grow (player lists, track grids, settings) goes inside scroll containers with fixed headers and footers. Primary actions stay pinned in a footer bar (never scroll away). Dialogs ≤ 560 dp wide, centred.
E8. CONSISTENCY: one `DRButton` (Primary, Secondary, Ghost, Danger; sizes L 56, M 48, S 40 dp; 16 dp radius; pressed scale 0.96 + haptic tick), one `DRCard`, one `DRChip`, one `DRToggle`, one `DRStepper`, one `DRTopBar` (back left, title centre, optional action right). Remove all one-off styles.

====================================================================
PART F — CONTROLS: BEST-IN-CLASS ON A PHONE
====================================================================
Research summary: Asphalt's simplified "TouchDrive" proved that most mobile players prefer steering assistance with skill kept in drift and boost timing. KartRider Rush+ keeps skill in drifts and nitro. Mario Kart Tour offered smart steering + auto-accelerate. Tilt is popular with a minority but is fiddly for drifting.
F1. Default scheme "SMART" for new players: auto-accelerate ON, smart steering ON (keeps you on the road, can't drop off edges), steering = drag anywhere in BOTTOM_LEFT. The thumb landing point becomes the centre, ±60 dp = full lock, response curve x^1.6, dead zone 6 dp.
   DRIFT = hold the large right button (or swipe up anywhere on the right half). ITEM = tap the item button (swipe down on it = fire back, hold = shield). BRAKE is a small button above DRIFT.
F2. "PRO" scheme: auto-accelerate optional, smart steering OFF (unlocks purple drifts), plus a GAS button, separate HOP and DRIFT if the player wants them, and analogue steering sensitivity 0.6–1.6.
F3. "TILT" scheme: rotation-vector sensor (not raw accelerometer), recalibrated at countdown, ±25° = full lock, adjustable dead zone, low-pass at 12 Hz, with BRAKE on the left half.
F4. "BUTTONS" scheme: ◀ ▶ large buttons (88 dp) with a soft analogue ramp (steer ramps 0→1 over 120 ms while held).
F5. Feel: steering input smoothing 50 ms (touch), drift direction locks on press, a visual drift-tier ring around the DRIFT button that fills with the tier colour, haptic ticks at each tier, and the button pulses when a boost is ready to release.
F6. Layout editor (Settings → Controls → Customise): drag and resize the action buttons inside the BOTTOM_RIGHT zone only (clamped so the guardrails hold), opacity 30–100%, left-handed mirror, and reset. Live preview on a still race frame.
F7. Gamepad: auto-detect. Left stick steer, RT gas, LT brake, A/R1 drift, B/L1 item, Start pause, with an on-screen glyph swap.
F8. Onboarding: a 60-second interactive tutorial on Study Desk (steer → drift → boost → item → finish), skippable, with the controls chosen up front from 3 big cards (Smart / Pro / Tilt) with animated previews.

====================================================================
PART G — THEMES, LAYOUT & MENUS
====================================================================
G1. Visual identity (matches the new app icon, a pencil rocket with a checkered band on navy with an amber lamp glow):
   Night Navy #0B1020 bg · Ink #121A33 surface · Lamp Amber #FFB547 primary · Hot Pink #FF3D7F accent · Cyan #2DE2E6 info/boost · Lime #A3E635 success · Coral #FB7185 danger · White 92% text, 64% secondary.
   Gradients only on primary CTAs (amber→pink) and the logo wordmark.
G2. HOME (landscape, two panes): left 7 columns show the live 3D desk with your kart and the realistic props on the Study Desk under the lamp, with a slow camera drift. Right 5 columns: the wordmark "DESK RACER" in Poppins Black with a "LAN" chip; a huge PLAY button (opens the Mode Picker); a row of secondary tiles: MULTIPLAYER (hotspot icon), GARAGE, SHOP (Part J), SETTINGS. Footer: player name chip, coin balance, Desk Pass level.
G3. MODE PICKER: horizontally scrolling cards with a 3D preview and a one-line description for Grand Prix, Quick Race, Time Trial, Multiplayer and Battle (if built).
G4. RACE SETUP: a two-pane sheet (left: track grid with a mini-map thumbnail from the spline, stars, best time and medal; right: "Race with bots?" toggle, bot count stepper, difficulty, laps, items, class) and a pinned footer [Back] [Start Race].
G5. TRACK THEMES: each track's menu card uses its surface texture as the card background with a dark scrim, plus its landmark prop rendered as a hero image (offscreen GL render at load, cached as a bitmap).
G6. Loading screen: the track card, a progress bar driven by real loading steps, and rotating tips.
G7. Transitions: shared-element style card → loading → fly-by, 250 ms, fade + scale. Respect reduced-motion.

====================================================================
PART H — GAME FEEL ADDITIONS (small, high impact)
====================================================================
H1. Speed sensation: camera FOV 62° → 70° with speed, FOV +6° on boost, subtle speed lines, ground-texture streaking via mip bias.
H2. Kart polish: suspension bob, wheel spin from distance, steering-angle front wheels (DRM1 wheel parts), dust from the surface type (wood chips, paper flecks, tile glints), skid marks.
H3. Props react: pylons (cones and pawns) are KNOCKABLE. On hit they tumble with simple rigid-body motion (angular velocity, gravity, ground friction), make a wood/plastic clack, and respawn upright after 6 s. They no longer block (they slow you by 15%). Landmarks stay solid.
H4. Photo mode in pause: free camera, hide HUD, save a screenshot to Pictures/DeskRacer via MediaStore (no permission needed on API 29+).

====================================================================
PART I — APP ICON & BRANDING
====================================================================
I1. The launcher icon is supplied by the pipeline (adaptive: `@mipmap/ic_launcher_dr_bg` + `@mipmap/ic_launcher_dr_fg`, plus legacy `ic_launcher` and `ic_launcher_round`). Keep `android:icon="@mipmap/ic_launcher"` and `android:roundIcon="@mipmap/ic_launcher_round"`. Do not regenerate or edit mipmaps or `mipmap-anydpi-v26/*.xml`.
I2. Add an Android 12+ SplashScreen (androidx.core:core-splashscreen is NOT available, so use the platform `windowSplashScreen*` theme attributes on API 31+, and a simple themed window background below) with background #0B1020 and the foreground icon.
I3. App name stays "Desk Racer LAN".

====================================================================
PART J — MONETIZATION-READY ARCHITECTURE (no pay-to-win, offline-first)
====================================================================
Build the systems now and keep real payments/ads behind interfaces, so they can be switched on later without touching gameplay:
J1. Currencies: COINS (earned in races, offline) and GEMS (premium; can also be earned slowly via the Desk Pass free track). Store balances in Prefs with an HMAC (key from Build fingerprint + install id) to deter casual tampering.
J2. DESK PASS (season, 40 tiers, XP from races offline): a free track (coins, paints, a horn) and a premium track (bodies, wheels, trails, emotes, nameplates). Progress works offline. The premium entitlement comes from `EntitlementStore`.
J3. SHOP: cosmetic only, never stats. Paints, decals, trails, horns, emotes, kart bodies, plus "Track Packs" (future cups). Bundles. Daily rotating offers computed locally from the date.
J4. HOST SHARES THE PARTY: in a LAN lobby, content owned by the HOST (e.g. a purchased Track Pack) is playable by everyone in that lobby for that session. Show a badge "Unlocked by <host>". This is the hotspot-native growth loop: one buyer upgrades the whole friend group's night.
J5. PRO UPGRADE (one-time): removes all ads, gives a +10% coin booster and an exclusive "Gold Pencil" body, and lets the HOST set up to 8 humans (free hosts: up to 6; joining is always free).
J6. ADS (optional, only when online, NEVER during a race or a LAN lobby countdown): rewarded video for "double race coins" (opt-in button on results), "free spin" on the daily wheel, and "retry Time Trial ghost". At most 1 interstitial every 3 solo races, only on the results screen and only when online, never for Pro users. If no ad is ready, hide the button (don't show an error).
J7. Interfaces: `BillingGateway` (purchase(sku), restore(), entitlements Flow) and `AdGateway` (isRewardedReady, showRewarded(onReward)). Implement `FakeBillingGateway` and `FakeAdGateway` (debug: instant success) now. Real Google Play Billing and AdMob implementations come later in a separate module when product IDs exist. Do NOT add those SDKs in this phase.
J8. Ethics: no loot boxes or gacha, no energy timers on core racing, no paywalls on multiplayer joining, and clear prices in INR with the local currency formatter.

====================================================================
PART K — STABILITY & PERFORMANCE (keep v2 rules)
====================================================================
Fixed 60 Hz sim + interpolated render; pooled objects; GL context-loss recovery; lifecycle-safe audio and sockets; auto quality; logs under the "DeskRacer" tag. Load assets on a background thread with a progress callback, and upload GL resources on the GL thread in small batches (≤ 8 ms per frame) so loading never stalls.

====================================================================
PART L — ACCEPTANCE CHECKLIST
====================================================================
[ ] Every track shows the realistic props from its JSON (chess pieces, cones, teacup, lamps, plants, bottle, toy car…). Nothing is a plain sphere or box.
[ ] Items are the battery, thumbtack, eraser, marbles, paper plane, magnet and star models.
[ ] Room backdrops are visible behind the desk with the miniature/tilt-shift feel. Shadows on High.
[ ] Poppins is the only font, and Orbitron/Space Grotesk are deleted.
[ ] HUD overlap tests (E6) pass at all 5 sizes × 2 font scales. The debug overlay shows no red.
[ ] Controls: Smart scheme by default; the layout editor clamps to zones; tutorial runs; gamepad works.
[ ] Midnight Office replaces Workshop Bench, and TrackValidator + HeadlessRaceTest pass on all 8 JSON tracks.
[ ] App icon is the pencil rocket and the splash shows on API 31+.
[ ] Shop, Desk Pass, Pro and fake ads work end-to-end in debug, and gameplay never needs internet.
[ ] 60 fps on Medium on a mid-range phone; no ANR while loading.

====================================================================
PART M — DELIVERY ORDER (compile after each; say "continue" if you stop)
====================================================================
1. Typography (D) + design-system components (E8) + HudLayout zones (E1–E5) + overlap tests (E6).
2. Asset repository + DRM2 loader + texture cache (B1–B2) + track JSON loading (B7), with Midnight Office restored.
3. Rendering upgrade (C1–C8): material shader, backdrops, shadows, road and desk textures, prop placement with instancing.
4. Items as models (B4) + knockable pylons (H3) + toy car kart (B8).
5. Controls overhaul (F1–F8).
6. Menus and themes (G1–G7) + splash (I2).
7. Monetization architecture with fakes (J1–J8).
8. Polish (H1, H2, H4), performance pass (C7, K), and full acceptance (L).
